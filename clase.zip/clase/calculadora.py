# Solicitar dos números al usuario
numero1 = int(input("Introduce el primer número: "))
numero2 = int(input("Introduce el segundo número: "))

# Solicitar el operador
operador = input("Introduce un operador (+, -, *, /): ")

# Realizar la operación correspondiente
if operador == '+':
    resultado = numero1 + numero2
    print(f"{numero1} + {numero2} = {resultado}")
elif operador == '-':
    resultado = numero1 - numero2
    print(f"{numero1} - {numero2} = {resultado}")
elif operador == '*':
    resultado = numero1 * numero2
    print(f"{numero1} * {numero2} = {resultado}")
elif operador == '/':
    if numero2 != 0:  # Evitar división por cero
        resultado = numero1 / numero2
        print(f"{numero1} / {numero2} = {resultado}")
    else:
        print("Error: División por cero no permitida.")
else:
    print("Operador no válido.")