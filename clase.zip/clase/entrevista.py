preguntas = [
    "¿Cuál es tu nombre?",
    "¿Cuántos años tienes?",
    "¿En qué ciudad vives?",
    "¿Cuál es tu color favorito?",
    "¿Tienes mascotas? (sí/no)",
    "¿Cuál es tu comida favorita?"
]

respuestas = {}  # Diccionario para almacenar las respuestas
resumen = []     # Lista para almacenar un resumen personalizado

for pregunta in preguntas:
    respuesta = input(pregunta + " ")
    respuestas[pregunta] = respuesta

# Uso de if para personalizar el resumen
if int(respuestas["¿Cuántos años tienes?"]) < 18:
    resumen.append("Eres menor de edad.")
else:
    resumen.append("Eres mayor de edad.")

if respuestas["¿Tienes mascotas? (sí/no)"].lower() == "sí":
    resumen.append("¡Qué bien que tengas mascotas!")
else:
    resumen.append("No tienes mascotas.")

if respuestas["¿Cuál es tu color favorito?"].lower() == "azul":
    resumen.append("El azul es un color muy popular.")

# Mostrar resultados
print("\n--- Respuestas de la entrevista ---")
for pregunta, respuesta in respuestas.items():
    print(f"{pregunta} {respuesta}")

print("\n--- Resumen personalizado ---")
for linea in resumen:
    print(linea)