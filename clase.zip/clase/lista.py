a = int(input("Ingrese un número: "))
b = int(input("Ingrese otro número: "))
ingresar = input("Ingrese 1 (suma), 2 (resta), 3 (multiplicación): ")
if ingresar == "1":
    print(a + b)
elif ingresar == "2":
    print(a - b)
elif ingresar == "3":
    print(a * b)
else:
    print("Opción no válida")
    