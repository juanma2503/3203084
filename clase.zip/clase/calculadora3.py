resultados = {}

operaciones = ["Suma (+)", "Resta (-)", "Multiplicación (*)", "División (/)"]

contador = 1 

while True:
    print("\nOperaciones disponibles:")
    for i, op in enumerate(operaciones, 1):
        print(f"{i}. {op}")
    print("5. Salir")

    seleccion = input("Selecciona una operación (1-5): ")

    if seleccion == '5':
        break

    if seleccion not in ['1', '2', '3', '4']:
        print("Selección no válida.")
        continue

    numero1 = int(input("Introduce el primer número: "))
    numero2 = int(input("Introduce el segundo número: "))

    if seleccion == '1':
        resultado = numero1 + numero2
        operacion_str = f"{numero1} + {numero2}"
    elif seleccion == '2':
        resultado = numero1 - numero2
        operacion_str = f"{numero1} - {numero2}"
    elif seleccion == '3':
        resultado = numero1 * numero2
        operacion_str = f"{numero1} * {numero2}"
    elif seleccion == '4':
        if numero2 != 0:
            resultado = numero1 / numero2
            operacion_str = f"{numero1} / {numero2}"
        else:
            print("Error: División por cero no permitida.")
            continue

    print(f"{operacion_str} = {resultado}")
    resultados[f"Operación {contador}: {operacion_str}"] = resultado
    contador += 1

print("\nResultados almacenados:")
for clave, valor in resultados.items():
    print(f"{clave}: {valor}")