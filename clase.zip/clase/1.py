a = 15
if a == 18:
    print("Usted es mayor de edad")
else:
    print("Usted es menor de edad")