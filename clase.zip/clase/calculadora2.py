resultados = []

operaciones = ["Suma (+)", "Resta (-)", "Multiplicación (*)", "División (/)"]

while True:
    print("\nOperaciones disponibles:")
    for i, op in enumerate(operaciones, 1):
        print(f"{i}. {op}")
    print("5. Salir")

    seleccion = input("Selecciona una operación (1-5): ")

    if seleccion == '5':
        break

    if seleccion not in ['1', '2', '3', '4']:
        print("Selección no válida.")
        continue

    numero1 = int(input("Introduce el primer número: "))
    numero2 = int(input("Introduce el segundo número: "))

    if seleccion == '1':
        resultado = numero1 + numero2
        print(f"{numero1} + {numero2} = {resultado}")
        resultados.append(resultado)
    elif seleccion == '2':
        resultado = numero1 - numero2
        print(f"{numero1} - {numero2} = {resultado}")
        resultados.append(resultado)
    elif seleccion == '3':
        resultado = numero1 * numero2
        print(f"{numero1} * {numero2} = {resultado}")
        resultados.append(resultado)
    elif seleccion == '4':
        if numero2 != 0:
            resultado = numero1 / numero2
            print(f"{numero1} / {numero2} = {resultado}")
            resultados.append(resultado)
        else:
            print("Error: División por cero no permitida.")

print("Resultados almacenados:", resultados)