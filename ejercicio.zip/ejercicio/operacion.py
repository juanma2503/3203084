from dato.var import c, b
print(c + b)